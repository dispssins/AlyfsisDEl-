/**
 * 
 */
/**
 * @author Refly
 * Nama File : Mahasiswa.java
 * NIM 		 : 11S16052
 * Kelas 	 : 13TI2	
 */
package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table (name="alumni")
public class Alumni{
	
	
	@Column(name="NIM")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="nama")
	private String nama;
	
	private String alamat;
	
	private String tempat_tanggal_lahir;
	
	private String j_kelamin;
	
	private String agama;
	
	private String instansi;
	
	private String jabatan;

	private String status;

	public Integer getId() {
		return id;
	}

	public String getNama() {
		return nama;
	}

	public String getAlamat() {
		return alamat;
	}

	public String getTempat_tanggal_lahir() {
		return tempat_tanggal_lahir;
	}

	public String getJ_kelamin() {
		return j_kelamin;
	}

	public String getAgama() {
		return agama;
	}

	public String getInstansi() {
		return instansi;
	}

	public String getJabatan() {
		return jabatan;
	}

	public String getStatus() {
		return status;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public void setTempat_tanggal_lahir(String tempat_tanggal_lahir) {
		this.tempat_tanggal_lahir = tempat_tanggal_lahir;
	}

	public void setJ_kelamin(String j_kelamin) {
		this.j_kelamin = j_kelamin;
	}

	public void setAgama(String agama) {
		this.agama = agama;
	}

	public void setInstansi(String instansi) {
		this.instansi = instansi;
	}

	public void setJabatan(String jabatan) {
		this.jabatan = jabatan;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}