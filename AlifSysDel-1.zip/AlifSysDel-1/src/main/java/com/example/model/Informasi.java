/**
 * 
 */
/**
 * @author Dian	
 */
package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table (name="informasi")
public class Informasi{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id_info;
	
	@Column(name="nama_pengirim")
	private String pengirim;
	
	private String tanggal_kirim;
	
	private String topik;
	
	private String isi;

	public Integer getId_info() {
		return id_info;
	}

	public String getPengirim() {
		return pengirim;
	}

	public String getTanggal_kirim() {
		return tanggal_kirim;
	}

	public String getTopik() {
		return topik;
	}

	public String getIsi() {
		return isi;
	}

	public void setId_info(Integer id_info) {
		this.id_info = id_info;
	}

	public void setPengirim(String pengirim) {
		this.pengirim = pengirim;
	}

	public void setTanggal_kirim(String tanggal_kirim) {
		this.tanggal_kirim = tanggal_kirim;
	}

	public void setTopik(String topik) {
		this.topik = topik;
	}

	public void setIsi(String isi) {
		this.isi = isi;
	}
}