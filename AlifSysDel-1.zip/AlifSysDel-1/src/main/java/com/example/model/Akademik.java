/**
 * 
 */
/**
 * Author Dian	
 */
package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table (name="akademik")
public class Akademik{
	
	@Column(name="NIM")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="nama")
	private String nama;
	
	private String angkatan;
	
	private String tgl_masuk;
	
	private String jurusan;

	public Integer getId() {
		return id;
	}

	public String getNama() {
		return nama;
	}

	public String getAngkatan() {
		return angkatan;
	}

	public String getTgl_masuk() {
		return tgl_masuk;
	}

	public String getJurusan() {
		return jurusan;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public void setAngkatan(String angkatan) {
		this.angkatan = angkatan;
	}

	public void setTgl_masuk(String tgl_masuk) {
		this.tgl_masuk = tgl_masuk;
	}

	public void setJurusan(String jurusan) {
		this.jurusan = jurusan;
	}
	
	
}